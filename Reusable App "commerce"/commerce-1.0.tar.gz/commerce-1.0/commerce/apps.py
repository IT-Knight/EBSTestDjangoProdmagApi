from django.apps import AppConfig


class CommerceConfig(AppConfig):
    name = 'commerce'
